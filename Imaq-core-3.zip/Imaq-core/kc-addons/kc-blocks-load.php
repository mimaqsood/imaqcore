<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}


class IMAQPRESSKcAddonClass{


	function __construct(){
		// integrate with kc with this hook
		add_action( 'init', array( $this, 'IMAQPRESSIntegrateWithKc' ) );
	}
     
    public function IMAQPRESSIntegrateWithKc(){
    	// check if king composer is not installed
    	if( ! defined('KC_VERSION') ){
    		add_action( 'admin_notices', array( $this, 'IMAQPRESSShowKcVersionNotice' ) );
    		return;
    	}

        // king composer addons
    	include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-slides.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-info-block-image.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-info-block-icon.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-about-us-block.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-video.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-fun-facts.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-button.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-team-list.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-profile-card.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-profile-section.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-event-list.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-conference-list.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-book-list.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-address-block.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-contact-info.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-latest-event.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-journal-article.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-selected-publications.php' );
        include( IMAQPRESS_ACC_PATH . '/kc-addons/IMAQPRESS-fluent-form.php' );

    }
    
    // show king composer version
    public function IMAQPRESSShowKcVersionNotice(){
    	$theme_data = wp_get_theme();
    	echo '<div class="notice notice-warning"><p>' . sprintf(__('<strong>%s</strong> recommends <strong><a href="'.site_url().'/wp-admin/plugin-install.php?s=king+composer&tab=search&type=term" target="_blank">King Composer</a></strong> plugin to be installed and activated on your site.', 'IMAQ'), $theme_data->get('Name')) . '</p></div>';
    }
}

new IMAQPRESSKcAddonClass();